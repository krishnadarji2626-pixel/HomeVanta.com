import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, Maximize2, Video, Sparkles, Phone, ShieldCheck, Compass, ArrowRight, Eye } from 'lucide-react';
import { Property } from '../types/property';

interface PropertyAnimationVideoSectionProps {
  properties: Property[];
  onSelectProperty: (property: Property) => void;
  onOpenEnquiry: (property: Property) => void;
  onOpenVideoModal: (property: Property) => void;
}

const FEATURED_VIDEO_LISTINGS = [
  {
    id: 'HV-SURAT-101',
    title: '3.5 BHK Sky Residence at Green City Gold',
    locality: 'Vesu, VIP Road Extn',
    price: '₹1.45 Cr',
    tourDuration: '2m 20s',
    videoType: '4K Architectural Fly-Through',
    scenes: [
      { name: 'Grand Entrance & Italian Marble Foyer', time: '0:00', image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Double-Height Living Lounge (22ft Ceiling)', time: '0:35', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Imported Designer Modular Kitchen', time: '1:10', image: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Master Bedroom Suite & Dressing', time: '1:45', image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=80' },
    ]
  },
  {
    id: 'HV-SURAT-102',
    title: '4 BHK Luxury Independent Bungalow with Private Lawn',
    locality: 'Pal, Pal-Hazira Road',
    price: '₹3.25 Cr',
    tourDuration: '3m 30s',
    videoType: 'Drone Aerial & Interior Walkthrough',
    scenes: [
      { name: 'Drone Aerial View & Private Lawn Entry', time: '0:00', image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Ground Floor Grand Living & Dining', time: '0:45', image: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Private Hydraulic Elevator & Lounge', time: '1:30', image: 'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Rooftop Sundeck Overlooking Greenery', time: '2:15', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80' },
    ]
  },
  {
    id: 'HV-SURAT-104',
    title: '3 BHK High-End Panoramic Living on VIP Road',
    locality: 'VIP Road, Opposite Shyam Mandir',
    price: '₹1.15 Cr',
    tourDuration: '2m 40s',
    videoType: 'High-Rise Panoramic Sunset Tour',
    scenes: [
      { name: 'Sky Residence Balcony Sunset View', time: '0:00', image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Bespoke Teak Wood Hall & Dining', time: '0:40', image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Acoustic Cinema Lounge & Club Access', time: '1:20', image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=80' },
      { name: 'Master Bed with Panoramic Glass Wall', time: '2:00', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80' },
    ]
  }
];

export const PropertyAnimationVideoSection: React.FC<PropertyAnimationVideoSectionProps> = ({
  properties,
  onSelectProperty,
  onOpenEnquiry,
  onOpenVideoModal,
}) => {
  const [selectedTourIndex, setSelectedTourIndex] = useState(0);
  const [activeSceneIndex, setActiveSceneIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  const activeTour = FEATURED_VIDEO_LISTINGS[selectedTourIndex];
  const activeScene = activeTour.scenes[activeSceneIndex];
  const matchedProperty = properties.find((p) => p.id === activeTour.id) || properties[0];

  // Auto scene advance & progress simulation
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            // Next scene
            setActiveSceneIndex((scenePrev) => (scenePrev + 1) % activeTour.scenes.length);
            return 0;
          }
          return prev + 1.5;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, activeTour.scenes.length]);

  return (
    <section className="py-16 bg-stone-950 text-white border-b border-stone-800 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-950/80 border border-amber-800/80 rounded-md text-xs font-bold text-amber-400 mb-3">
              <Video className="w-3.5 h-3.5 text-amber-400" />
              <span>Surat Property Animation & 4K Video Walkthrough Tours</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black font-display tracking-tight text-white">
              Experience Properties Before Visiting in Person
            </h2>

            <p className="text-xs sm:text-sm text-stone-400 mt-1.5 max-w-2xl font-normal leading-relaxed">
              Eliminate wasted site visits. Watch high-definition animated room walkthroughs, drone fly-throughs, and view corridors across Vesu, Pal, and VIP Road.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-4 text-xs text-stone-300">
            <div className="p-3 bg-stone-900/80 border border-stone-800 rounded-xl">
              <span className="font-extrabold text-amber-400 block text-base font-display">100%</span>
              <span className="text-[11px] text-stone-400">Actual Site Footage</span>
            </div>
            <div className="p-3 bg-stone-900/80 border border-stone-800 rounded-xl">
              <span className="font-extrabold text-emerald-400 block text-base font-display">360°</span>
              <span className="text-[11px] text-stone-400">Room Perspectives</span>
            </div>
          </div>
        </div>

        {/* Property Selector Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-none">
          {FEATURED_VIDEO_LISTINGS.map((tour, idx) => (
            <button
              key={tour.id}
              onClick={() => {
                setSelectedTourIndex(idx);
                setActiveSceneIndex(0);
                setProgress(0);
                setIsPlaying(true);
              }}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap border shrink-0 flex items-center gap-2 ${
                selectedTourIndex === idx
                  ? 'bg-amber-600 text-white border-amber-500 shadow-md'
                  : 'bg-stone-900/80 text-stone-300 border-stone-800 hover:bg-stone-800 hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>{tour.title}</span>
              <span className="text-[10px] opacity-80 font-mono">({tour.price})</span>
            </button>
          ))}
        </div>

        {/* Main Video Cinema Container */}
        <div className="relative aspect-16/9 sm:aspect-21/9 bg-stone-900 rounded-3xl overflow-hidden border border-stone-800 shadow-2xl group">
          {/* Animated Zoom / Ken-Burns Canvas */}
          <div
            className="absolute inset-0 transition-transform duration-1000 ease-out"
            style={{
              transform: `scale(${isPlaying ? 1.05 : 1})`,
            }}
          >
            <img
              src={activeScene.image}
              alt={activeScene.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover filter brightness-95"
            />
          </div>

          {/* Contrast Scrims */}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-stone-950/70 pointer-events-none" />

          {/* Top Info Bar */}
          <div className="absolute top-4 sm:top-6 inset-x-4 sm:inset-x-6 flex items-center justify-between gap-4 pointer-events-none">
            <div className="bg-stone-900/85 backdrop-blur-md border border-stone-700/80 rounded-2xl px-4 py-2.5 pointer-events-auto">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  Live Walkthrough Simulation
                </span>
                <span className="text-stone-500">·</span>
                <span className="text-xs font-mono text-stone-300">{activeTour.videoType}</span>
              </div>
              <h3 className="text-sm sm:text-base font-extrabold text-white">
                {activeTour.title}
              </h3>
              <p className="text-xs text-stone-300">
                {activeTour.locality} · <span className="text-amber-400 font-bold">{activeTour.price}</span>
              </p>
            </div>

            {/* Current Scene Badge */}
            <div className="hidden sm:flex items-center gap-2 bg-stone-900/85 backdrop-blur-md border border-stone-700/80 rounded-2xl px-4 py-2.5 text-right">
              <div>
                <span className="text-[10px] text-stone-400 font-semibold block uppercase tracking-wider">
                  Current Room Focus
                </span>
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5 justify-end">
                  <Compass className="w-3.5 h-3.5 text-amber-400" />
                  {activeScene.name}
                </span>
              </div>
            </div>
          </div>

          {/* Center Big Play Button if paused */}
          {!isPlaying && (
            <button
              onClick={() => setIsPlaying(true)}
              className="absolute z-20 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 sm:w-20 h-16 sm:h-20 rounded-full bg-amber-600/90 hover:bg-amber-600 text-white flex items-center justify-center shadow-2xl transition-transform hover:scale-110 cursor-pointer"
            >
              <Play className="w-8 sm:w-10 h-8 sm:h-10 fill-current ml-1" />
            </button>
          )}

          {/* Bottom Video Controls & Chapter Jump Bar */}
          <div className="absolute bottom-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-t from-black via-black/80 to-transparent">
            {/* Progress line */}
            <div className="w-full h-1 bg-stone-700 rounded-full mb-3 overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-100 ease-linear rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {/* Playback controls */}
              <div className="flex items-center gap-3 text-xs">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-1.5 text-white hover:text-amber-400 transition-colors cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                </button>

                <button
                  onClick={() => {
                    setProgress(0);
                    setActiveSceneIndex(0);
                    setIsPlaying(true);
                  }}
                  className="p-1.5 text-stone-400 hover:text-white transition-colors cursor-pointer"
                  title="Replay from start"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 text-stone-400 hover:text-white transition-colors cursor-pointer"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                <span className="text-xs font-mono text-stone-300">
                  Scene {activeSceneIndex + 1} of {activeTour.scenes.length} · {activeTour.tourDuration}
                </span>
              </div>

              {/* Action Buttons Right on the Video! */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenEnquiry(matchedProperty)}
                  className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl transition-all cursor-pointer whitespace-nowrap shadow-xs"
                >
                  Book Site Visit via Form
                </button>

                <a
                  href="tel:+918879719844"
                  className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap border border-stone-600"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-400 fill-current" />
                  <span>Call Hardik: 8879719844</span>
                </a>

                <button
                  onClick={() => onOpenVideoModal(matchedProperty)}
                  className="p-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl cursor-pointer"
                  title="Open Full 360 Interactive Video Modal"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Room Chapters Grid below video */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {activeTour.scenes.map((scene, idx) => (
            <button
              key={idx}
              onClick={() => {
                setActiveSceneIndex(idx);
                setProgress(0);
                setIsPlaying(true);
              }}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                activeSceneIndex === idx
                  ? 'bg-amber-600/20 border-amber-500 text-white'
                  : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-white hover:border-stone-700'
              }`}
            >
              <div className="text-[10px] font-mono text-amber-400 font-bold mb-0.5">
                Room {idx + 1} · {scene.time}
              </div>
              <div className="text-xs font-semibold line-clamp-1">{scene.name}</div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
